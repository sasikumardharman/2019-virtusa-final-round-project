<?php 
 $con=new mysqli('localhost','root','','shopping_cart'); 
 $name = $_POST['b1'];
 $sql="select * from stock_detail where productID='$name';";
 $result = mysqli_query($con,$sql);
 $row = mysqli_fetch_array($result);
 $mna=$row['productName'] ;
 $mno=$row['productID'];
 $des=$row['descr'];
 $p=$row['price'];
 $query = "INSERT INTO sasi(modalname,modelid,discr,price)VALUES('$mna','$mno','$des','$p');";
 $result = mysqli_query($con,$query); 
 if($result)
 {
	 header("Location: display.php");
 }
 ?>
	